### powershell script to install | uninstall portworx csi driver on windows node.
### may need to run Unblock-File $baseDir\pxplugin.ps1
### need to ensure nssm is in the path '$NSSMPath'

### action one of "install | uninstall | status | start | stop"
param
(
     [string][parameter(Mandatory=$true)]$action
)

$baseDir="c:\pxplugin"
$NSSMPath="$baseDir\nssm-2.24\win64\nssm.exe"
$plugin="px-csi-win"
$logDir="$baseDir\logs"
$hostname=hostname.exe
$nodeid= kubectl describe node $hostname | Select-String Internal |  %{($_ -split "\s+")[2]}
$appBin="$baseDir\pxplugin.exe"

function Install-NodeService()
{
    Write-Host "Installing px-csi-win node plugin startup service... hostname $nodeid"

    Unblock-File -Path $NSSMPath
    Unblock-File -Path $appBin

    & $NSSMPath install $plugin $appBin
    & $NSSMPath set $plugin AppParameters -v=2 --endpoint unix://C:\\var\\lib\\kubelet\\plugins\\pxd.portworx.com\\csi.sock --nodeid=$nodeid
    & $NSSMPath set $plugin AppDirectory $baseDir
    & $NSSMPath set $plugin DisplayName "$plugin - Portworx CSI Service"
    & $NSSMPath set $plugin Description "Portworx Windows Startup, configures Portworx CSI storage driver for this node."

    # Configure it to auto-start by default.
    & $NSSMPath set $plugin Start SERVICE_AUTO_START
    & $NSSMPath set $plugin ObjectName LocalSystem
    & $NSSMPath set $plugin Type SERVICE_WIN32_OWN_PROCESS

    # Throttle process restarts if Felix restarts in under 1500ms.
    & $NSSMPath set $plugin AppThrottle 1500

    # Create the log directory if needed.
    if (-Not(Test-Path "$logDir"))
    {
        write "Creating log directory."
        md -Path "$logDir"
    }
    & $NSSMPath set $plugin AppStdout $logDir\$plugin.log
    & $NSSMPath set $plugin AppStderr $logDir\$plugin.err.log

    # Configure online file rotation.
    & $NSSMPath set $plugin AppRotateFiles 1
    & $NSSMPath set $plugin AppRotateOnline 1
    # Rotate once per day.
    & $NSSMPath set $plugin AppRotateSeconds 86400
    # Rotate after 10MB.
    & $NSSMPath set $plugin AppRotateBytes 10485760

    Write-Host "Done installing $plugin startup service."
}

function Remove-NodeService()
{
    & $NSSMPath remove $plugin confirm
}



if ($action -eq "install")
{
    Install-NodeService
}
elseif ($action -eq "uninstall")
{
    Remove-NodeService
}
elseif ($action -eq "status")
{
    Get-Service -name $plugin
}
elseif ($action -eq "start")
{
    Start-Service -name $plugin
}
elseif ($action -eq "stop")
{
    Stop-Service -name $plugin
}
else
{
    Write-Host "Invalid -action value. Valid values are: ['install', 'status', 'uninstall', 'start', 'stop']"
    Exit
}
